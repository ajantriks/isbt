<a name="browser-compatibility"></a>
##Browser Compatibility
Frank is focused on modern desktop and mobile browser support. Frank works *decently* on Internet Explorer 8+. No guarantees are given for any earlier IE versions.

<a name="wordpress-compatibility"></a>
##WordPress Compatibility
Frank was built and tested on WordPress 3.4.3. Any future development of the theme will be focused on supporting the most current version of WordPress.