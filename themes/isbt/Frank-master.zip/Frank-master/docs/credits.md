<a name="credits"></a>
##Credits
This theme was built with significant help of some great folks. My sincere thanks to [Felix Holmgren](http://twitter.com/felixhgren), [Jon Christopher](http://twitter.com/jchristopher) and [Josh McDonald](https://twitter.com/onestepcreative) for their tremendous contributions.