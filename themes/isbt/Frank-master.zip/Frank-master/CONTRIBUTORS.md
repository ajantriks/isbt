PJ Onori <pj@somerandomdude.com>
Jonathan Christopher <jonathandchr@gmail.com>
Evster88 <evan.jacobs@brafton.com>
Felix Holmgren <felix@sunnyzebra.com>
Sebastian Grodzicki <sebastian@grodzicki.pl>
Elliott Stocks <elliottstocks@hotmail.co.uk>
Julián Porta <julian@porta.sh>
Jeffrey Hearn <cowbellemoo@gmail.com>
Chris Danek <chris@veboolabs.com>
Brendan Tobolaski <btobolaski@aero.und.edu>
Jérôme Pinguet <jerome@jerome.cc>
Chris Bujok <chris.bujok@gmail.com>
Boris Kuzmanov <boriskuzmanov2@gmail.com>
JR Tashjian <jrtashjian@gmail.com>
Peter Keating <peter@moov2.com>